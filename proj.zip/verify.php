

<!doctype html>
<html lang="en">
<head>
  <title>Enterprise Document Validation</title> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!--link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous"-->
  <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Enterprise Document Validation</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="issue.php">Issue Document </a></li>
      <li><a href="verify.php">Verify Document</a></li>
      <li><a href="logout.php">Log Out</a></li>
    </ul>
  </div>
</nav>



  <div class="container">
    <div class="row">
      <div class="col-xs-12" style="height:25px;"></div>
    </div>
    <div class="row">
      <div class="col-sm"><center>
        <font style="font-family: 'Rammetto One', cursive;" size="25">Enterprise Document Validation</font>
        <br/><br/><br/>
        
        <div class="form-group">
          <label class="custom-file">
            <input type="file" id="hashFile" class="custom-file-input">
            <input type="hidden" id="owner" value="blockchain">
            <span class="custom-file-control" data-content="Choose file..."></span>
          </label>
        </div>
        <div class="form-group">
          <button type='button' id="sendHashButton" onclick="send()" class="btn btn-primary"/>
            Issue Document to Blockchain
          </button>
          <button type='button' id= "findHashButton" onclick="find()" class="btn btn-primary"/>
            Verify Document on Blockchain
          </button>
        </div>
          <div id=responseText></div>
        </div>
      </div>
    </div>
  </div>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>

<script src="sha256.js"></script>
<script src="web3.min.js"></script>
<script src="notaryWebLib.js"></script>
<script src="app.js"></script>
</body>
</html>